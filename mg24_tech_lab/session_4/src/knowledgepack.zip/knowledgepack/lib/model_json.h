#ifndef __MODEL_JSON_H__
#define __MODEL_JSON_H__

const char recognition_model_string_json[] = {"{\"NumModels\":1,\"ModelIndexes\":{\"0\":\"GUITAR_NOTE_RECOGNITION_DEMO_RANK_0\"},\"ModelDescriptions\":[{\"Name\":\"GUITAR_NOTE_RECOGNITION_DEMO_RANK_0\",\"ClassMaps\":{\"1\":\"A\",\"2\":\"B\",\"3\":\"D\",\"4\":\"E\",\"5\":\"E1\",\"6\":\"G\",\"7\":\"Unknown\",\"0\":\"Unknown\"},\"ModelType\":\"TensorFlowLiteforMicrocontrollers\",\"FeatureFunctions\":[\"MFCC\",\"MFCC\",\"MFCC\",\"MFCC\",\"MFCC\",\"MFCC\",\"MFCC\",\"MFCC\",\"MFCC\",\"MFCC\",\"MFCC\",\"MFCC\",\"MFCC\",\"MFCC\",\"MFCC\",\"MFCC\",\"MFCC\",\"MFCC\",\"MFCC\",\"MFCC\",\"MFCC\",\"MFCC\",\"MFCC\",\"MFCC\",\"MFCC\",\"MFCC\",\"MFCC\",\"MFCC\",\"MFCC\",\"MFCC\",\"MFCC\",\"MFCC\",\"MFCC\",\"MFCC\",\"MFCC\",\"MFCC\",\"MFCC\",\"MFCC\",\"MFCC\",\"MFCC\",\"MFCC\",\"MFCC\",\"MFCC\",\"MFCC\",\"MFCC\",\"MFCC\",\"MFCC\",\"MFCC\",\"MFCC\",\"MFCC\",\"MFCC\",\"MFCC\",\"MFCC\",\"MFCC\",\"MFCC\",\"MFCC\",\"MFCC\",\"MFCC\",\"MFCC\",\"MFCC\"]}]}"};

int recognition_model_string_json_len = sizeof(recognition_model_string_json);

#endif /* __MODEL_JSON_H__ */
